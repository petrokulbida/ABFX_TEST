<div class="title"><?php echo $title; ?></div>

<div class="gridly">
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick large"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick large"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick large"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
  <div class="brick small"></div>
</div>

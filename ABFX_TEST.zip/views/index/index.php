<div class="title"><?php echo $title; ?></div>
<div class="left_content">
<?php echo $category; ?>
</div>
<div class="right_content">

</div>
